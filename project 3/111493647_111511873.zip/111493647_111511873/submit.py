#do not modify the function names
#You are given L and M as input
#Each of your functions should return the minimum possible L value alongside the marker positions
#Or return -1,[] if no solution exists for the given L
import sys
import profile
import itertools
from math import *
#take inputs length and order
L = int(sys.argv[1])
M = int(sys.argv[2])
def dr(ruler):
    diffs = []
    for i,a in enumerate(ruler[:-1]):
        for b in ruler[i+1:len(ruler)]:
            diffs.append(abs(a-b))
    return sorted(diffs)

def validate(ruler):
    diffs = dr(ruler)
    if len(diffs) == len(set(diffs)):
    	return True
	
def G(M):
	A = (M*M) - (2*M*sqrt(M)) + sqrt(M) - 2 
	if M<=4:
		B= (M*(M-1)/2)
	else:
		B= (M*(M-1)/2)+1
	n = max(A,B)
	return B
	
#Your backtracking function implementation
def BT(L, M):
    "*** YOUR CODE HERE ***"
    print"Using Backtracking:"
    n = G(M)
    if L>=n:
    	flag = 0
    	while(flag == 0):
	   		for ruler in itertools.combinations(range(L), M):
	   			if validate(ruler):
					flag = 1
					return ruler
			L += 1
    return -1,[]
#Your backtracking+Forward checking function implementation
def FC(L, M):
    "*** YOUR CODE HERE ***"
    print"Using Backtracking+FC:"
    def golomb(M,n):
		x[M-1] = n
		if(validate(x)):
				print(x)
		else:
			for K1 in range(G(M-1),G(M)):
				golomb(M-1,K1)
    n = G(M)
    x=[]
    for i in range(M):
		x.append(0)
    if L >= n:
		for K in range(n,L+1):
			golomb(M,K)
		return True
    return -1,[]
#Bonus: backtracking + constraint propagation
def CP(L, M):
    "*** YOUR CODE HERE ***"
	
    return -1,[]
profile.run('print BT(L,M); print')
profile.run('print FC(L,M); print')